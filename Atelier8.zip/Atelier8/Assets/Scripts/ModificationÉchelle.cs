using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ModificationÉchelle : MonoBehaviour
{
    Vector3 Agrandissement = new Vector3(1.5f, 1.5f, 1.5f);

    public void Agrandir()
    {
        transform.localScale = Agrandissement;
    }

    public void Rétrécir()
    {
        transform.localScale = Vector3.one;
    }
}
