using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ModificationTexte : MonoBehaviour
{
    Text TexteMessage;
    void Awake()
    {
        TexteMessage = GetComponent<Text>();
    }

    public void ModifierTexte(string messageTexte)
    {
        TexteMessage.text = messageTexte;
    }
}
